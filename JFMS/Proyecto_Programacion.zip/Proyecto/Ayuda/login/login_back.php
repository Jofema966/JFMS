 <?php
   // session_start();
    // en este ejemplo solo se trabaja con sesiones
    // por lo tanto no se busca al usuario en una base de datos
   //$_SESSION['usr_name'] = $_POST['usr_name'];
   //header('location: ../index.php');
?>